package com.sawtiya.sync;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.List;

/** الشاشة الرئيسية على التلفزيون: القنوات والتحكم والسجل. */
public class MainActivity extends Activity {
    final Handler h = new Handler(Looper.getMainLooper());
    TextView status, delay, levels, phone, log;
    Button syncBtn, playBtn, muteBtn;
    LinearLayout list;
    int listCount = -1;
    final Runnable tick = new Runnable() {
        @Override public void run() { update(); h.postDelayed(this, 500); }
    };

    SyncService s() { return SyncService.I; }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        SyncService.start(this);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.HORIZONTAL);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setBackgroundColor(Color.rgb(12, 20, 40));
        root.setPadding(36, 24, 36, 24);

        // العمود الأول: التحكم
        LinearLayout ctl = new LinearLayout(this);
        ctl.setOrientation(LinearLayout.VERTICAL);
        TextView title = text("مزامنة الصوتية", 28, Color.WHITE);
        status = text("", 20, Color.rgb(80, 230, 220));
        delay = text("", 17, Color.rgb(210, 220, 240));
        levels = text("", 15, Color.rgb(170, 185, 210));
        phone = text("", 15, Color.rgb(255, 200, 120));
        ctl.addView(title); ctl.addView(status); ctl.addView(delay); ctl.addView(levels); ctl.addView(phone);

        syncBtn = btn("زامن الآن", v -> run(x -> x.syncNow()));
        playBtn = btn("تشغيل", v -> run(x -> x.togglePlay()));
        ctl.addView(row(syncBtn, playBtn, btn("المشغّل العائم", v -> run(x -> { x.overlay.show(); moveTaskToBack(true); }))));
        ctl.addView(row(
                btn("−1", v -> run(x -> x.setDelay(x.pictureDelay - 1000))),
                btn("−0.1", v -> run(x -> x.setDelay(x.pictureDelay - 100))),
                btn("+0.1", v -> run(x -> x.setDelay(x.pictureDelay + 100))),
                btn("+1", v -> run(x -> x.setDelay(x.pictureDelay + 1000))),
                btn("صفر", v -> run(x -> x.setDelay(0)))));
        muteBtn = btn("كتم القناة", v -> run(x -> x.setChannelMuted(!x.channelMuted)));
        ctl.addView(row(muteBtn,
                btn("تصحيح −50", v -> run(x -> x.setCalib(x.calibMs - 50))),
                btn("تصحيح +50", v -> run(x -> x.setCalib(x.calibMs + 50)))));
        ctl.addView(row(btn("إضافة قناة", v -> addDialog()), btn("التوكن", v -> tokenDialog())));
        log = text("", 13, Color.rgb(190, 200, 220));
        ScrollView lsv = new ScrollView(this);
        lsv.addView(log);
        ctl.addView(lsv, new LinearLayout.LayoutParams(-1, 0, 1f));
        root.addView(ctl, new LinearLayout.LayoutParams(0, -1, 1.6f));

        // العمود الثاني: القنوات
        LinearLayout side = new LinearLayout(this);
        side.setOrientation(LinearLayout.VERTICAL);
        side.setPadding(24, 0, 0, 0);
        side.addView(text("القنوات الصوتية", 22, Color.WHITE));
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv = new ScrollView(this);
        sv.addView(list);
        side.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        root.addView(side, new LinearLayout.LayoutParams(0, -1, 1f));

        setContentView(root);
        syncBtn.requestFocus();
    }

    @Override protected void onResume() { super.onResume(); h.post(tick); }
    @Override protected void onPause() { super.onPause(); h.removeCallbacks(tick); }

    interface Act { void go(SyncService s); }
    void run(Act a) { SyncService x = s(); if (x != null) a.go(x); }

    void update() {
        SyncService x = s();
        if (x == null) { status.setText("جارٍ تشغيل الخدمة…"); return; }
        status.setText((x.title.isEmpty() ? "" : x.title + " • ") + x.status);
        delay.setText(x.delayText());
        levels.setText(x.levelsText());
        phone.setText("تحكم من الموبايل (نفس الواي فاي): " + x.web.address() + "\nالزر الأحمر مرتين بالريموت = المشغّل العائم");
        syncBtn.setText(x.syncing ? "إلغاء المزامنة" : "زامن الآن");
        playBtn.setText(x.playing ? "إيقاف مؤقت" : "تشغيل");
        muteBtn.setText(x.channelMuted ? "سماع القناة" : "كتم القناة");
        log.setText(x.logText());
        List<String[]> all = x.channels.all();
        if (all.size() != listCount) fillList(x, all);
    }

    void fillList(SyncService x, List<String[]> all) {
        listCount = all.size();
        list.removeAllViews();
        int anis = x.channels.anisCount();
        for (int i = 0; i < all.size(); i++) {
            final String[] c = all.get(i);
            final int ci = i - anis;
            Button b = btn(c[0], v -> x.play(c[0], c[1]));
            b.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
            if (ci >= 0) b.setOnLongClickListener(v -> {
                new AlertDialog.Builder(this).setMessage("حذف " + c[0] + "؟")
                        .setPositiveButton("حذف", (d, w) -> { x.channels.removeCustom(ci); listCount = -1; })
                        .setNegativeButton("إلغاء", null).show();
                return true;
            });
            list.addView(b, new LinearLayout.LayoutParams(-1, -2));
        }
    }

    void addDialog() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        EditText n = new EditText(this); n.setHint("اسم القناة");
        EditText u = new EditText(this); u.setHint("http://"); u.setInputType(InputType.TYPE_TEXT_VARIATION_URI);
        l.addView(n); l.addView(u);
        new AlertDialog.Builder(this).setTitle("إضافة قناة").setView(l)
                .setPositiveButton("حفظ", (d, w) -> run(x -> { x.channels.add(n.getText().toString(), u.getText().toString()); listCount = -1; }))
                .setNegativeButton("إلغاء", null).show();
    }

    void tokenDialog() {
        SyncService x = s();
        if (x == null) return;
        EditText t = new EditText(this);
        t.setText(x.channels.token());
        new AlertDialog.Builder(this).setTitle("توكن أنيس").setView(t)
                .setPositiveButton("حفظ", (d, w) -> { x.channels.setToken(t.getText().toString()); listCount = -1; })
                .setNegativeButton("إلغاء", null).show();
    }

    TextView text(String s, int sp, int color) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(sp); t.setTextColor(color); t.setPadding(6, 6, 6, 6);
        return t;
    }

    Button btn(String s, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(s); b.setTextSize(17); b.setAllCaps(false);
        b.setFocusable(true); b.setOnClickListener(l);
        return b;
    }

    LinearLayout row(View... vs) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        for (View v : vs) r.addView(v, new LinearLayout.LayoutParams(0, -2, 1f));
        return r;
    }
}
