package com.sawtiya.sync;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;

import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.audio.AudioProcessor;
import androidx.media3.exoplayer.DefaultRenderersFactory;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.audio.AudioSink;
import androidx.media3.exoplayer.audio.DefaultAudioSink;
import androidx.media3.exoplayer.audio.TeeAudioProcessor;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.Date;
import java.util.Locale;

/** الخدمة الأساسية: تشغيل الصوتية + المزامنة + أوامر الرسيفر + المشغّل العائم + تحكم الموبايل. */
public class SyncService extends Service {
    static volatile SyncService I;
    static final int OUT_LATENCY_MS = 250;   // تقدير تأخير إخراج الصوت داخل المشغّل

    final Handler main = new Handler(Looper.getMainLooper());
    final Track chTrack = new Track(10000);  // 100 ثانية
    final Track cmTrack = new Track(4000);   // 40 ثانية
    final ArrayDeque<String> logs = new ArrayDeque<>();

    SharedPreferences prefs;
    Channels channels;
    ExoPlayer player;
    Capture cap;
    Overlay overlay;
    Web web;
    BroadcastReceiver rx;

    volatile String title = "", url = "";
    volatile String status = "اختر قناة صوتية";
    volatile int pictureDelay;
    volatile boolean filling, channelMuted, syncing, cancelSync, playing;
    volatile long lastRxMs;
    volatile int calibMs;
    volatile float cmLevel;
    volatile float volume = 1f;

    static void start(Context c) {
        Intent i = new Intent(c, SyncService.class);
        if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i); else c.startService(i);
    }

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public void onCreate() {
        super.onCreate();
        I = this;
        prefs = getSharedPreferences("s", MODE_PRIVATE);
        channels = new Channels(prefs);
        calibMs = prefs.getInt("calib", 0);
        goForeground();
        enableSystemPermissions();
        buildPlayer();
        cap = new Capture(chTrack, this::log);
        overlay = new Overlay(this);
        web = new Web(this);
        web.start();
        rx = new BroadcastReceiver() {
            @Override public void onReceive(Context c, Intent i) { onReceiverMessage(i); }
        };
        IntentFilter f = new IntentFilter(Rx.ACTION);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(rx, f, Context.RECEIVER_EXPORTED);
        else registerReceiver(rx, f);
        log("الخدمة اشتغلت • تحكم الموبايل: " + web.address());
    }

    @Override public int onStartCommand(Intent i, int flags, int id) { return START_STICKY; }

    @Override public void onDestroy() {
        cancelSync = true;
        try { unregisterReceiver(rx); } catch (Exception ignored) {}
        cap.stop();
        web.stop();
        overlay.hide();
        player.release();
        I = null;
        super.onDestroy();
    }

    // ---------- الصلاحيات (نحن تطبيق نظام) ----------
    void enableSystemPermissions() {
        try {
            String me = getPackageName() + "/" + KeyService.class.getName();
            String cur = Settings.Secure.getString(getContentResolver(), "enabled_accessibility_services");
            if (cur == null) cur = "";
            if (!cur.contains(me)) {
                Settings.Secure.putString(getContentResolver(), "enabled_accessibility_services", cur.isEmpty() ? me : cur + ":" + me);
            }
            Settings.Secure.putInt(getContentResolver(), "accessibility_enabled", 1);
        } catch (Exception e) {
            log("تعذر تفعيل خدمة الريموت تلقائياً: " + e.getMessage());
        }
        try {
            android.app.AppOpsManager ops = (android.app.AppOpsManager) getSystemService(APP_OPS_SERVICE);
            java.lang.reflect.Method m = ops.getClass().getMethod("setMode", String.class, int.class, String.class, int.class);
            m.invoke(ops, "android:system_alert_window", android.os.Process.myUid(), getPackageName(), 0);
        } catch (Exception ignored) {}
    }

    void goForeground() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel("play", "تشغيل الصوتية", NotificationManager.IMPORTANCE_LOW));
            b = new Notification.Builder(this, "play");
        } else b = new Notification.Builder(this);
        PendingIntent pi = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        Notification n = b.setContentTitle("مزامنة الصوتية").setContentText("تعمل بالخلفية")
                .setSmallIcon(android.R.drawable.ic_media_play).setContentIntent(pi).build();
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        else startForeground(1, n);
    }

    // ---------- المشغّل ----------
    void buildPlayer() {
        final CmSink sink = new CmSink();
        DefaultRenderersFactory rf = new DefaultRenderersFactory(this) {
            @Override protected AudioSink buildAudioSink(Context c, boolean floatOut, boolean playbackParams) {
                return new DefaultAudioSink.Builder(c)
                        .setAudioProcessors(new AudioProcessor[]{new TeeAudioProcessor(sink)})
                        .build();
            }
        };
        player = new ExoPlayer.Builder(this, rf).build();
        player.setAudioAttributes(new androidx.media3.common.AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_SPEECH).build(), false);
        player.addListener(new Player.Listener() {
            @Override public void onPlayerError(PlaybackException e) {
                log("خطأ بالبث (" + e.getErrorCodeName() + ") — إعادة اتصال");
                status = "إعادة اتصال بالبث…";
                main.postDelayed(() -> { if (!url.isEmpty() && playing) { player.prepare(); player.play(); } }, 3000);
            }
            @Override public void onPlaybackStateChanged(int s) {
                if (s == Player.STATE_BUFFERING) status = "جارٍ التحميل…";
                else if (s == Player.STATE_READY && !syncing && playing) status = channelMuted ? "قيد التشغيل • صوت القناة مكتوم" : "قيد التشغيل • اضغط زامن الآن";
                else if (s == Player.STATE_ENDED && playing) { log("البث انتهى — إعادة اتصال"); main.postDelayed(() -> { player.prepare(); player.play(); }, 2000); }
            }
        });
    }

    /** يلتقط PCM الصوتية وقت تشغيلها لبناء منحنى البدايات. */
    final class CmSink implements TeeAudioProcessor.AudioBufferSink {
        int rate, ch, enc;
        Onset on;
        double expEnd;
        final float[] mono = new float[4096];

        @Override public void flush(int sampleRateHz, int channelCount, int encoding) {
            rate = sampleRateHz; ch = channelCount; enc = encoding;
            on = rate > 0 ? new Onset(rate, cmTrack) : null;
            expEnd = 0;
        }

        @Override public void handleBuffer(ByteBuffer buffer) {
            if (on == null || enc != C.ENCODING_PCM_16BIT || ch <= 0) return;
            ByteBuffer bb = buffer.duplicate().order(ByteOrder.LITTLE_ENDIAN);
            int frames = bb.remaining() / (2 * ch);
            if (frames <= 0) return;
            double dur = frames * 1000.0 / rate;
            double now = SystemClock.elapsedRealtime() + OUT_LATENCY_MS + calibMs;
            double end;
            if (expEnd != 0 && Math.abs(expEnd + dur - now) < 600) end = expEnd + dur + (now - (expEnd + dur)) * 0.02;
            else end = now;
            expEnd = end;
            int done = 0;
            while (done < frames) {
                int k = Math.min(mono.length, frames - done);
                for (int i = 0; i < k; i++) {
                    float s = 0;
                    for (int c = 0; c < ch; c++) s += bb.getShort() / 32768f;
                    mono[i] = s / ch;
                }
                long e2 = (long) (end - (frames - done - k) * 1000.0 / rate);
                on.push(mono, k, e2);
                done += k;
            }
            cmLevel = on.level;
        }
    }

    void play(String name, String u) {
        main.post(() -> {
            title = name; url = Channels.clean(u); playing = true;
            prefs.edit().putString("lastName", name).putString("lastUrl", url).apply();
            cmTrack.clear();
            player.setMediaItem(MediaItem.fromUri(url));
            player.prepare();
            player.setVolume(volume);
            player.play();
            status = "جارٍ التحميل…";
            log("تشغيل: " + name);
        });
    }

    void togglePlay() {
        main.post(() -> {
            if (url.isEmpty()) {
                String n = prefs.getString("lastName", ""), u = prefs.getString("lastUrl", "");
                if (!u.isEmpty()) play(n, u); else status = "اختر قناة صوتية";
                return;
            }
            if (player.isPlaying()) { player.pause(); playing = false; status = "متوقف مؤقتاً"; }
            else { playing = true; player.prepare(); player.play(); }
        });
    }

    void stopAudio() { main.post(() -> { player.stop(); playing = false; status = "الصوت متوقف"; }); }

    void setVolume(float v) { volume = Math.max(0f, Math.min(1f, v)); main.post(() -> player.setVolume(volume)); }

    // ---------- الرسيفر ----------
    void setDelay(int ms) {
        pictureDelay = Math.max(0, Math.min(60000, ms));
        Rx.send("0118", String.valueOf(pictureDelay), this::log);
    }

    void setChannelMuted(boolean m) {
        channelMuted = m;
        Rx.send("0117", m ? "0" : "1", this::log);
    }

    void onReceiverMessage(Intent i) {
        Bundle e = i.getExtras();
        if (e == null) return;
        StringBuilder sb = new StringBuilder();
        for (String k : e.keySet()) sb.append(k).append('=').append(e.get(k)).append(' ');
        Object d = e.get("display"), t = e.get("displayTime");
        boolean disp = d instanceof Boolean ? (Boolean) d : (d instanceof Number && ((Number) d).intValue() != 0);
        filling = disp;
        if (t instanceof Number) pictureDelay = Math.max(0, ((Number) t).intValue());
        lastRxMs = SystemClock.elapsedRealtime();
        log("الرسيفر: " + sb.toString().trim());
    }

    void setCalib(int ms) {
        calibMs = Math.max(-2000, Math.min(2000, ms));
        prefs.edit().putInt("calib", calibMs).apply();
    }

    // ---------- المزامنة ----------
    void syncNow() {
        if (syncing) { cancelSync = true; status = "جارٍ الإلغاء…"; return; }
        if (url.isEmpty() || !playing) { status = "شغّل الصوتية أولاً ثم زامن"; return; }
        syncing = true;
        cancelSync = false;
        new Thread(this::doSync, "sync").start();
    }

    private void doSync() {
        boolean wasMuted = channelMuted;
        try {
            chTrack.clear();
            if (!cap.start(getCacheDir())) { status = "تعذر التقاط صوت القناة"; return; }
            if (wasMuted) setChannelMuted(false);
            long t0 = SystemClock.elapsedRealtime();
            int d0 = pictureDelay;
            Matcher.Result cand = null, fin = null;
            status = "يستمع للقناة والصوتية…";
            while (!cancelSync) {
                Thread.sleep(1500);
                long now = SystemClock.elapsedRealtime();
                long el = now - t0;
                if (el > 85000) break;
                if (cmTrack.last() < now - 3000) { status = "الصوتية متوقفة أو تحمّل…"; continue; }
                int templ = 12000;
                int maxLag = (int) Math.min(60000, el - templ - 1500);
                if (maxLag < 2000) { status = "يستمع للقناة والصوتية… " + el / 1000 + " ث"; continue; }
                Matcher.Result r = Matcher.match(chTrack, cmTrack, now - 300, templ, -3000, maxLag);
                if (r == null) { status = "يجمع صوت… " + el / 1000 + " ث"; continue; }
                log("قياس: " + r);
                if (r.ok()) {
                    if (cand != null && Math.abs(r.lagMs - cand.lagMs) <= 150) {
                        fin = r;
                        fin.lagMs = (r.lagMs + cand.lagMs) / 2;
                        break;
                    }
                    cand = r;
                    status = String.format(Locale.US, "مرشح %.1f ث • يتأكد…", r.lagMs / 1000f);
                } else {
                    status = "يدوّر على تطابق… " + el / 1000 + " ث";
                }
            }
            if (fin == null) {
                status = cancelSync ? "أُلغيت المزامنة"
                        : "ما لكيت تطابق • تأكد أنها نفس المباراة وصوت الملعب مسموع";
                if (wasMuted) setChannelMuted(true);
                return;
            }
            log(String.format(Locale.US, "الصوتية متأخرة %.2f ث • تأخير الصورة الحالي %.1f ث", fin.lagMs / 1000f, d0 / 1000f));
            apply(d0 + fin.lagMs);

            // تحقق بعد التطبيق
            status = "يتأكد من التوقيت…";
            waitFilling(Math.abs(fin.lagMs) + 4000);
            chTrack.clear();
            long tv = SystemClock.elapsedRealtime();
            Matcher.Result v = null;
            while (!cancelSync && SystemClock.elapsedRealtime() - tv < 25000) {
                Thread.sleep(1500);
                long now = SystemClock.elapsedRealtime();
                if (now - tv < 13500) continue;
                v = Matcher.match(chTrack, cmTrack, now - 2200, 8000, -2000, 2000);
                if (v != null && v.ok()) break;
            }
            if (v != null && v.ok()) {
                log("تحقق: " + v);
                if (Math.abs(v.lagMs) > 1500) log("فرق التحقق كبير وغير متوقع — ما طبقته");
                else if (Math.abs(v.lagMs) > 120) { apply(pictureDelay + v.lagMs); log("تصحيح بسيط طُبق"); }
            } else log("ما تأكد التحقق — بقى التأخير على القياس الأول");
            setChannelMuted(true);
            wasMuted = false;
            status = String.format(Locale.US, "تمت المزامنة ✓ • تأخير الصورة %.1f ث", pictureDelay / 1000f);
        } catch (InterruptedException ignored) {
        } catch (Exception e) {
            status = "تعذرت المزامنة: " + e.getMessage();
            log(status);
        } finally {
            cap.stop();
            if (cancelSync && wasMuted) setChannelMuted(true);
            syncing = false;
        }
    }

    private void apply(int newDelay) {
        if (newDelay < 0) {
            setDelay(0);
            final int pause = Math.min(10000, -newDelay);
            log(String.format(Locale.US, "الصوتية أسرع من الصورة — نأخرها %.1f ث", pause / 1000f));
            main.post(() -> { player.pause(); main.postDelayed(() -> player.play(), pause); });
        } else {
            if (newDelay > 60000) log("الفرق أكبر من حد الرسيفر (60 ث)");
            setDelay(newDelay);
        }
    }

    private void waitFilling(long timeout) throws InterruptedException {
        long t = SystemClock.elapsedRealtime();
        Thread.sleep(800);
        while (SystemClock.elapsedRealtime() - t < timeout && !cancelSync) {
            if (!filling && SystemClock.elapsedRealtime() - t > 1500) break;
            Thread.sleep(300);
        }
        Thread.sleep(700);
    }

    // ---------- أدوات ----------
    String levelsText() {
        StringBuilder sb = new StringBuilder("القناة: ");
        boolean any = false;
        for (int c = 0; c < 8; c++) {
            int bars = (int) Math.min(5, cap.levels[c] * 20);
            if (bars > 0) any = true;
            sb.append(c + 1).append(bar(bars)).append(' ');
        }
        if (!cap.running) return "صوت القناة: يُلتقط وقت المزامنة فقط  •  الصوتية " + bar((int) Math.min(5, cmLevel * 20));
        return sb + (any ? "" : "(صامت)") + "  •  الصوتية " + bar((int) Math.min(5, cmLevel * 20));
    }

    static String bar(int n) {
        StringBuilder s = new StringBuilder();
        for (int i = 0; i < 5; i++) s.append(i < n ? '▮' : '▯');
        return s.toString();
    }

    String delayText() { return String.format(Locale.US, "تأخير الصورة %.1f ث%s • تصحيح %+d ms", pictureDelay / 1000f, filling ? " (يملأ…)" : "", calibMs); }

    void log(String s) {
        String t = new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date());
        synchronized (logs) {
            logs.addFirst(t + "  " + s);
            while (logs.size() > 80) logs.removeLast();
        }
    }

    String logText() {
        StringBuilder sb = new StringBuilder();
        synchronized (logs) { for (String l : logs) sb.append(l).append('\n'); }
        return sb.toString();
    }
}
