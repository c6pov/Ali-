package com.sawtiya.sync;

import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.List;

/** قنوات الصوتية: قائمة أنيس الجاهزة (بالتوكن) + القنوات المضافة. */
final class Channels {
    static final String ANIS_BASE = "http://radio.anisfm.vip/live/";
    static final String DEFAULT_TOKEN = "V0EG8BOAKJ";
    static final String[][] ANIS = {
        {"Anis Max 1", "mx/1"}, {"Anis Max 2", "mx/2"}, {"Anis Max 3", "mx/3"},
        {"Anis Max 4", "mx/4"}, {"Anis Max 5", "mx/5"}, {"Anis Max 6", "mx/6"},
        {"Anis Sport 1", "pn/1"}, {"Anis Sport 2", "pn/2"}, {"Anis Sport 3", "pn/3"},
        {"Anis Sport 4", "pn/4"}, {"Anis Sport 5", "pn/5"}, {"Anis Sport 6", "pn/6"},
        {"Anis Sport 7", "pn/7"}, {"Anis Sport 8", "pn/8"}, {"Anis Sport 9", "pn/9"},
        {"Anis Italy 1", "it/1"}, {"Anis Italy 2", "it/2"},
        {"Anis DE 1", "gr/1"}, {"Anis DE 2", "gr/2"},
        {"Anis Thm8h 1", "sa/1"}, {"Anis Thm8h 2", "sa/2"}, {"Anis Thm8h 3", "sa/3"},
        {"Anis Shasha", "sha/1"}, {"Anis Shahid", "sha/2"},
        {"Anis EN 1", "pn/1EN"}, {"Anis EN 2", "pn/2EN"},
        {"Anis FR 1", "pn/1FR"}, {"Anis FR 2", "pn/2FR"},
        {"Anis Xtra 1", "sha/XR1"}, {"Anis Xtra 2", "sha/XR2"},
        {"Anis Al Kass 1", "sha/K1"}, {"Anis Al Kass 2", "sha/K2"},
        {"Anis Max 1 Low", "mx/1L"}, {"Anis Max 2 Low", "mx/2L"}, {"Anis Max 3 Low", "mx/3L"},
        {"Anis Max 4 Low", "mx/4L"}, {"Anis Max 5 Low", "mx/5L"}, {"Anis Max 6 Low", "mx/6L"},
    };

    final SharedPreferences p;
    Channels(SharedPreferences p) { this.p = p; }

    String token() { return p.getString("token", DEFAULT_TOKEN); }
    void setToken(String t) { p.edit().putString("token", t.trim()).apply(); }

    /** كل القنوات: [اسم، رابط] */
    List<String[]> all() {
        List<String[]> out = new ArrayList<>();
        String tok = token();
        for (String[] a : ANIS) out.add(new String[]{a[0], ANIS_BASE + a[1] + "?token=" + tok});
        out.addAll(custom());
        return out;
    }

    int anisCount() { return ANIS.length; }

    List<String[]> custom() {
        List<String[]> out = new ArrayList<>();
        for (String line : p.getString("custom", "").split("\n")) {
            int i = line.indexOf('\t');
            if (i > 0) out.add(new String[]{line.substring(0, i), line.substring(i + 1)});
        }
        return out;
    }

    void add(String name, String url) {
        name = name.replace('\t', ' ').replace('\n', ' ').trim();
        url = clean(url);
        if (url.isEmpty()) return;
        if (name.isEmpty()) name = url;
        String cur = p.getString("custom", "");
        p.edit().putString("custom", (cur.isEmpty() ? "" : cur + "\n") + name + "\t" + url).apply();
    }

    void removeCustom(int idx) {
        List<String[]> c = custom();
        if (idx < 0 || idx >= c.size()) return;
        c.remove(idx);
        StringBuilder sb = new StringBuilder();
        for (String[] x : c) { if (sb.length() > 0) sb.append('\n'); sb.append(x[0]).append('\t').append(x[1]); }
        p.edit().putString("custom", sb.toString()).apply();
    }

    /** يستورد M3U أو صيغة "0|الاسم|الرابط". يرجع عدد القنوات المضافة. */
    int importText(String text) {
        int n = 0;
        String pending = null;
        for (String raw : text.split("\r?\n")) {
            String l = raw.trim();
            if (l.isEmpty()) continue;
            if (l.startsWith("#EXTINF")) { int c = l.lastIndexOf(','); pending = c >= 0 ? l.substring(c + 1).trim() : null; continue; }
            if (l.startsWith("#")) continue;
            String[] parts = l.split("\\|");
            if (parts.length >= 3 && parts[2].startsWith("http")) { add(parts[1], parts[2]); n++; pending = null; continue; }
            if (l.startsWith("http")) { add(pending == null ? "" : pending, l); n++; pending = null; }
        }
        return n;
    }

    static String clean(String url) {
        url = url.trim();
        while (url.endsWith("#")) url = url.substring(0, url.length() - 1);
        return url;
    }
}
