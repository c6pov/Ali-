package com.sawtiya.sync;

import android.accessibilityservice.AccessibilityService;
import android.os.SystemClock;
import android.view.KeyEvent;
import android.view.accessibility.AccessibilityEvent;

/** الزر الأحمر (أو Audio) مرتين بالريموت = إظهار/إخفاء المشغّل العائم. */
public class KeyService extends AccessibilityService {
    long lastRed, lastAudio;

    @Override public void onAccessibilityEvent(AccessibilityEvent e) {}
    @Override public void onInterrupt() {}

    @Override protected boolean onKeyEvent(KeyEvent e) {
        int k = e.getKeyCode();
        boolean red = k == KeyEvent.KEYCODE_PROG_RED;
        boolean audio = k == KeyEvent.KEYCODE_MEDIA_AUDIO_TRACK;
        if (!red && !audio) return false;
        SyncService s = SyncService.I;
        if (s == null) {
            if (e.getAction() == KeyEvent.ACTION_UP) SyncService.start(this);
            return false;
        }
        // إذا المشغّل ظاهر، خلي الزر يوصله (يسكّره)
        if (s.overlay.isShown()) return false;
        if (e.getAction() != KeyEvent.ACTION_UP) return false;
        long now = SystemClock.uptimeMillis();
        if (red) {
            if (now - lastRed < 700) { lastRed = 0; s.overlay.show(); return true; }
            lastRed = now;
        } else {
            if (now - lastAudio < 700) { lastAudio = 0; s.overlay.show(); return true; }
            lastAudio = now;
        }
        return false;
    }
}
