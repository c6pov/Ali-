package com.sawtiya.sync;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;

/** أوامر محرك الرسيفر المدمج: 0118 = تأخير الصورة (ms) ، 0117 = صوت القناة (1 تشغيل / 0 كتم). */
final class Rx {
    static final int PORT = 51021;
    static final String ACTION = "com.tms.message.in.action";

    static void send(String code, String value, Capture.Log log) {
        final String msg = "Play\n" + code + "\n" + value;
        new Thread(() -> {
            try (DatagramSocket s = new DatagramSocket()) {
                byte[] out = msg.getBytes(StandardCharsets.US_ASCII);
                s.send(new DatagramPacket(out, out.length, InetAddress.getByName("127.0.0.1"), PORT));
                if (code.equals("0117")) {
                    s.setSoTimeout(800);
                    byte[] buf = new byte[256];
                    DatagramPacket in = new DatagramPacket(buf, buf.length);
                    try {
                        s.receive(in);
                        log.log("المحرك: " + new String(buf, 0, in.getLength(), StandardCharsets.US_ASCII).replace('\n', ' '));
                    } catch (java.net.SocketTimeoutException ignored) {}
                }
            } catch (Exception e) {
                log.log("فشل أمر الرسيفر " + code + ": " + e.getMessage());
            }
        }).start();
    }
}
