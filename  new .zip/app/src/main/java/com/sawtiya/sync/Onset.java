package com.sawtiya.sync;

/** يحوّل الصوت لمنحنى "بدايات" (صافرة، هتاف، ضربة كرة) كل 10ms عبر FFT 512 و24 حزمة لوغاريتمية. */
final class Onset {
    static final int N = 512;
    static final float[] COS = new float[N / 2], SIN = new float[N / 2], WIN = new float[N];
    static {
        for (int i = 0; i < N / 2; i++) {
            COS[i] = (float) Math.cos(2 * Math.PI * i / N);
            SIN[i] = (float) -Math.sin(2 * Math.PI * i / N);
        }
        for (int i = 0; i < N; i++) WIN[i] = (float) (0.5 - 0.5 * Math.cos(2 * Math.PI * i / (N - 1)));
    }

    final int rate, hop;
    final Track out;
    final float[] ring = new float[N], re = new float[N], im = new float[N];
    final int[] edges;
    final float[] prev;
    int pos, since;
    float peak;
    volatile float level;

    Onset(int rate, Track out) {
        this.rate = rate; this.out = out;
        hop = Math.max(1, rate / 100);
        int nb = 24;
        edges = new int[nb + 1];
        double f0 = 150, f1 = Math.min(6000, rate / 2.0 - 100);
        int last = 0;
        for (int b = 0; b <= nb; b++) {
            double f = f0 * Math.pow(f1 / f0, (double) b / nb);
            int bin = (int) Math.round(f * N / rate);
            if (bin <= last) bin = last + 1;
            edges[b] = Math.min(bin, N / 2 - 1);
            last = edges[b];
        }
        prev = new float[nb];
    }

    /** mono[0..n) ، endTime = وقت سماع آخر عينة (elapsedRealtime ms) */
    void push(float[] mono, int n, long endTime) {
        for (int i = 0; i < n; i++) {
            float x = mono[i];
            ring[pos] = x;
            pos = (pos + 1) & (N - 1);
            float a = Math.abs(x);
            if (a > peak) peak = a;
            if (++since >= hop) {
                since = 0;
                long tt = endTime - (long) (n - 1 - i) * 1000L / rate;
                out.add(tt, frame());
                level = level * 0.9f + peak * 0.1f;
                peak = 0;
            }
        }
    }

    private float frame() {
        for (int i = 0; i < N; i++) { re[i] = ring[(pos + i) & (N - 1)] * WIN[i]; im[i] = 0; }
        fft(re, im);
        float flux = 0;
        for (int b = 0; b < prev.length; b++) {
            double e = 1e-9;
            for (int k = edges[b]; k < edges[b + 1]; k++) e += re[k] * re[k] + im[k] * im[k];
            float le = (float) Math.log10(e);
            float d = le - prev[b];
            if (d > 0) flux += d;
            prev[b] = le;
        }
        return flux;
    }

    static void fft(float[] re, float[] im) {
        int n = re.length;
        for (int i = 1, j = 0; i < n; i++) {
            int bit = n >> 1;
            for (; (j & bit) != 0; bit >>= 1) j ^= bit;
            j ^= bit;
            if (i < j) {
                float t = re[i]; re[i] = re[j]; re[j] = t;
                t = im[i]; im[i] = im[j]; im[j] = t;
            }
        }
        for (int len = 2; len <= n; len <<= 1) {
            int step = n / len;
            for (int i = 0; i < n; i += len)
                for (int k = 0; k < len / 2; k++) {
                    float wr = COS[k * step], wi = SIN[k * step];
                    int a = i + k, b = a + len / 2;
                    float xr = re[b] * wr - im[b] * wi, xi = re[b] * wi + im[b] * wr;
                    re[b] = re[a] - xr; im[b] = im[a] - xi;
                    re[a] += xr; im[a] += xi;
                }
        }
    }
}
