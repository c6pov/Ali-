package com.sawtiya.sync;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** صفحة تحكم بالموبايل على http://IP:8090 */
final class Web {
    static final int PORT = 8090;
    final SyncService s;
    ServerSocket ss;
    volatile boolean run;

    Web(SyncService s) { this.s = s; }

    void start() {
        run = true;
        new Thread(() -> {
            try {
                ss = new ServerSocket(PORT);
                while (run) {
                    Socket c = ss.accept();
                    new Thread(() -> handle(c)).start();
                }
            } catch (Exception e) {
                if (run) s.log("تعذر تشغيل تحكم الموبايل: " + e.getMessage());
            }
        }, "web").start();
    }

    void stop() { run = false; try { if (ss != null) ss.close(); } catch (Exception ignored) {} }

    String address() {
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces()))
                for (InetAddress a : Collections.list(ni.getInetAddresses()))
                    if (a instanceof Inet4Address && !a.isLoopbackAddress()) return "http://" + a.getHostAddress() + ":" + PORT;
        } catch (Exception ignored) {}
        return "(لا توجد شبكة)";
    }

    private void handle(Socket c) {
        try (Socket sock = c) {
            sock.setSoTimeout(10000);
            InputStream in = sock.getInputStream();
            String line = readLine(in);
            if (line == null) return;
            String[] parts = line.split(" ");
            if (parts.length < 2) return;
            String method = parts[0], target = parts[1];
            int len = 0;
            String h;
            while ((h = readLine(in)) != null && !h.isEmpty())
                if (h.toLowerCase().startsWith("content-length:")) len = Integer.parseInt(h.substring(15).trim());
            byte[] body = new byte[Math.min(len, 2_000_000)];
            int got = 0;
            while (got < body.length) { int r = in.read(body, got, body.length - got); if (r < 0) break; got += r; }
            String path = target, query = "";
            int q = target.indexOf('?');
            if (q >= 0) { path = target.substring(0, q); query = target.substring(q + 1); }
            Map<String, String> p = parse(query);
            String type = "text/plain; charset=utf-8", resp = "ok";
            switch (path) {
                case "/": type = "text/html; charset=utf-8"; resp = page(); break;
                case "/s": type = "application/json; charset=utf-8"; resp = state(); break;
                case "/play": {
                    List<String[]> all = s.channels.all();
                    int i = toInt(p.get("i"), -1);
                    if (i >= 0 && i < all.size()) s.play(all.get(i)[0], all.get(i)[1]);
                    break;
                }
                case "/add": s.channels.add(nz(p.get("n")), nz(p.get("u"))); break;
                case "/del": s.channels.removeCustom(toInt(p.get("i"), -1)); break;
                case "/token": s.channels.setToken(nz(p.get("t"))); break;
                case "/import": {
                    String text = method.equals("POST") ? new String(body, 0, got, StandardCharsets.UTF_8) : download(nz(p.get("u")));
                    resp = "تمت إضافة " + s.channels.importText(text) + " قناة";
                    break;
                }
                case "/c": {
                    String cmd = nz(p.get("cmd"));
                    switch (cmd) {
                        case "sync": s.syncNow(); break;
                        case "toggle": s.togglePlay(); break;
                        case "mute": s.setChannelMuted(true); break;
                        case "unmute": s.setChannelMuted(false); break;
                        case "overlay": s.overlay.toggle(); break;
                        case "delay": s.setDelay(toInt(p.get("ms"), s.pictureDelay)); break;
                        case "dd": s.setDelay(s.pictureDelay + toInt(p.get("ms"), 0)); break;
                        case "calib": s.setCalib(s.calibMs + toInt(p.get("ms"), 0)); break;
                        case "vol": s.setVolume(s.volume + toInt(p.get("v"), 0) / 100f); break;
                    }
                    break;
                }
                default: resp = "not found";
            }
            byte[] out = resp.getBytes(StandardCharsets.UTF_8);
            OutputStream os = sock.getOutputStream();
            os.write(("HTTP/1.1 200 OK\r\nContent-Type: " + type + "\r\nContent-Length: " + out.length
                    + "\r\nCache-Control: no-store\r\nConnection: close\r\n\r\n").getBytes(StandardCharsets.UTF_8));
            os.write(out);
            os.flush();
        } catch (Exception ignored) {}
    }

    private static String readLine(InputStream in) throws java.io.IOException {
        StringBuilder sb = new StringBuilder();
        int ch;
        while ((ch = in.read()) >= 0) {
            if (ch == '\n') break;
            if (ch != '\r') sb.append((char) ch);
            if (sb.length() > 16384) break;
        }
        return ch < 0 && sb.length() == 0 ? null : sb.toString();
    }

    private static Map<String, String> parse(String q) {
        Map<String, String> m = new HashMap<>();
        for (String kv : q.split("&")) {
            int i = kv.indexOf('=');
            if (i <= 0) continue;
            try { m.put(kv.substring(0, i), URLDecoder.decode(kv.substring(i + 1), "UTF-8")); } catch (Exception ignored) {}
        }
        return m;
    }

    private static String download(String u) {
        try {
            HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
            c.setConnectTimeout(8000); c.setReadTimeout(15000);
            StringBuilder sb = new StringBuilder();
            try (BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), StandardCharsets.UTF_8))) {
                String l; while ((l = r.readLine()) != null) sb.append(l).append('\n');
            }
            return sb.toString();
        } catch (Exception e) { return ""; }
    }

    static String nz(String x) { return x == null ? "" : x; }
    static int toInt(String x, int d) { try { return Integer.parseInt(x.trim()); } catch (Exception e) { return d; } }

    static String js(String x) {
        StringBuilder sb = new StringBuilder("\"");
        for (char ch : x.toCharArray()) {
            if (ch == '"' || ch == '\\') sb.append('\\').append(ch);
            else if (ch < 32) sb.append(' ');
            else sb.append(ch);
        }
        return sb.append('"').toString();
    }

    private String state() {
        StringBuilder sb = new StringBuilder("{");
        sb.append("\"title\":").append(js(s.title)).append(',')
          .append("\"status\":").append(js(s.status)).append(',')
          .append("\"delay\":").append(js(s.delayText())).append(',')
          .append("\"muted\":").append(s.channelMuted).append(',')
          .append("\"playing\":").append(s.playing).append(',')
          .append("\"syncing\":").append(s.syncing).append(',')
          .append("\"token\":").append(js(s.channels.token())).append(',')
          .append("\"anis\":").append(s.channels.anisCount()).append(',')
          .append("\"log\":").append(js(s.logText().replace('\n', '|'))).append(',')
          .append("\"ch\":[");
        List<String[]> all = s.channels.all();
        for (int i = 0; i < all.size(); i++) { if (i > 0) sb.append(','); sb.append(js(all.get(i)[0])); }
        return sb.append("]}").toString();
    }

    private String page() {
        return "<!doctype html><html dir=rtl lang=ar><head><meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'>"
            + "<title>مزامنة الصوتية</title><style>"
            + "body{font-family:sans-serif;background:#0e1630;color:#eef;margin:0;padding:12px}"
            + "button{background:#1d3a6e;color:#fff;border:1px solid #3d6ea8;border-radius:10px;padding:12px;font-size:16px;margin:3px}"
            + ".row{display:flex;gap:4px}.row button{flex:1}.st{color:#50e6dc;font-size:17px;margin:6px 0}"
            + "input{width:100%;box-sizing:border-box;padding:10px;margin:3px 0;border-radius:8px;border:0;font-size:15px}"
            + ".ch{padding:12px;border-bottom:1px solid #24375e;display:flex;justify-content:space-between}"
            + "h3{margin:16px 0 6px}pre{white-space:pre-wrap;font-size:12px;color:#aab}"
            + "</style></head><body>"
            + "<h2 id=t>مزامنة الصوتية</h2><div class=st id=s></div><div id=d></div>"
            + "<div class=row><button onclick=c('sync') id=sb>زامن الآن</button><button onclick=c('toggle') id=pb>تشغيل</button></div>"
            + "<div class=row><button onclick=\"c('dd&ms=-1000')\">−1</button><button onclick=\"c('dd&ms=-100')\">−0.1</button>"
            + "<button onclick=\"c('dd&ms=100')\">+0.1</button><button onclick=\"c('dd&ms=1000')\">+1</button><button onclick=\"c('delay&ms=0')\">صفر</button></div>"
            + "<div class=row><button onclick=c('mute')>كتم القناة</button><button onclick=c('unmute')>سماع القناة</button><button onclick=c('overlay')>المشغّل العائم</button></div>"
            + "<div class=row><button onclick=\"c('vol&v=-10')\">صوت −</button><button onclick=\"c('vol&v=10')\">صوت +</button>"
            + "<button onclick=\"c('calib&ms=-50')\">تصحيح −50</button><button onclick=\"c('calib&ms=50')\">تصحيح +50</button></div>"
            + "<h3>القنوات</h3><div id=list></div>"
            + "<h3>توكن أنيس</h3><input id=tok><button onclick=\"g('/token?t='+e('tok'))\">حفظ التوكن</button>"
            + "<h3>إضافة قناة</h3><input id=n placeholder='الاسم'><input id=u placeholder='الرابط http://'>"
            + "<button onclick=\"g('/add?n='+e('n')+'&u='+e('u'))\">إضافة</button>"
            + "<h3>استيراد قائمة (M3U أو 0|الاسم|الرابط)</h3><input type=file id=f onchange=up()>"
            + "<input id=mu placeholder='أو رابط القائمة'><button onclick=\"g('/import?u='+e('mu'))\">استيراد من رابط</button>"
            + "<h3>السجل</h3><pre id=lg></pre>"
            + "<script>"
            + "function e(i){return encodeURIComponent(document.getElementById(i).value)}"
            + "function g(u){fetch(u).then(r=>r.text()).then(t=>{if(t!='ok')alert(t);load()})}"
            + "function c(x){fetch('/c?cmd='+x).then(load)}"
            + "function up(){var f=document.getElementById('f').files[0];if(!f)return;f.text().then(t=>fetch('/import',{method:'POST',body:t})).then(r=>r.text()).then(t=>{alert(t);load()})}"
            + "var tokSet=false,lastN=-1;"
            + "function load(){fetch('/s').then(r=>r.json()).then(s=>{"
            + "t.innerText=s.title||'مزامنة الصوتية';document.getElementById('s').innerText=s.status;d.innerText=s.delay;"
            + "sb.innerText=s.syncing?'إلغاء المزامنة':'زامن الآن';pb.innerText=s.playing?'إيقاف مؤقت':'تشغيل';"
            + "lg.innerText=s.log.split('|').join('\\n');if(!tokSet){tok.value=s.token;tokSet=true}"
            + "if(s.ch.length!=lastN){lastN=s.ch.length;var L=document.getElementById('list');L.innerHTML='';"
            + "s.ch.forEach((n,i)=>{var dv=document.createElement('div');dv.className='ch';"
            + "var a=document.createElement('span');a.innerText='▶ '+n;a.onclick=()=>fetch('/play?i='+i).then(load);dv.appendChild(a);"
            + "if(i>=s.anis){var x=document.createElement('span');x.innerText='حذف';x.onclick=()=>{if(confirm('حذف '+n+'؟'))g('/del?i='+(i-s.anis))};dv.appendChild(x)}"
            + "L.appendChild(dv)})}})}"
            + "load();setInterval(load,1500);"
            + "</script></body></html>";
    }
}
