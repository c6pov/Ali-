package com.sawtiya.sync;

import java.util.Arrays;

/** سلسلة زمنية دائرية من (وقت، قيمة) لقوة البدايات الصوتية كل 10ms. */
final class Track {
    private final long[] t;
    private final float[] v;
    private int head, size;

    Track(int cap) { t = new long[cap]; v = new float[cap]; }

    synchronized void add(long time, float val) {
        t[head] = time; v[head] = val;
        head = (head + 1) % t.length;
        if (size < t.length) size++;
    }

    synchronized void clear() { head = 0; size = 0; }

    synchronized long last() { return size == 0 ? Long.MIN_VALUE : t[(head - 1 + t.length) % t.length]; }

    /** القيم على شبكة 10ms بين start و end. NaN = لا توجد بيانات. */
    synchronized float[] grid(long start, long end) {
        int n = (int) Math.max(0, (end - start) / 10);
        float[] g = new float[n];
        Arrays.fill(g, Float.NaN);
        int base = (head - size + t.length) % t.length;
        for (int k = 0; k < size; k++) {
            int i = (base + k) % t.length;
            long tt = t[i];
            if (tt < start || tt >= end) continue;
            int j = (int) ((tt - start) / 10);
            if (j >= 0 && j < n) g[j] = Float.isNaN(g[j]) ? v[i] : Math.max(g[j], v[i]);
        }
        for (int j = 1; j < n - 1; j++)
            if (Float.isNaN(g[j]) && !Float.isNaN(g[j - 1]) && !Float.isNaN(g[j + 1])) g[j] = (g[j - 1] + g[j + 1]) / 2;
        return g;
    }
}
