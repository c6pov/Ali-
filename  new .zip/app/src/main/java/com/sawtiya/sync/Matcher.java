package com.sawtiya.sync;

import java.util.Locale;

/** يلكى الإزاحة الزمنية بين صوت القناة والصوتية بالارتباط المتقاطع. */
final class Matcher {
    static final class Result {
        int lagMs;      // موجب = الصوتية متأخرة عن القناة
        float score, ratio;
        boolean ok() { return score >= 0.25f && ratio >= 1.2f; }
        @Override public String toString() {
            return String.format(Locale.US, "فرق %.2f ث • تطابق %.2f • وضوح %.2f", lagMs / 1000f, score, ratio);
        }
    }

    /**
     * يقارن آخر templMs من الصوتية مع تاريخ القناة.
     * الصوتية بالوقت t تقابل القناة بالوقت t - L ، و L بين minLag و maxLag.
     */
    static Result match(Track ch, Track cm, long end, int templMs, int minLagMs, int maxLagMs) {
        long start = end - templMs;
        float[] c = cm.grid(start, end);
        float[] h = ch.grid(start - maxLagMs, end - minLagMs);
        int n = c.length;
        if (n == 0) return null;
        boolean[] cv = new boolean[n];
        detrend(c, cv);
        int cvalid = 0;
        for (boolean b : cv) if (b) cvalid++;
        if (cvalid < n * 0.7) return null;
        boolean[] hv = new boolean[h.length];
        detrend(h, hv);
        double cn = 0;
        for (float x : c) cn += x * x;
        cn = Math.sqrt(cn);
        if (cn < 1e-6) return null;

        int K = (maxLagMs - minLagMs) / 10 + 1;
        double[] pre = new double[h.length + 1];
        int[] pv = new int[h.length + 1];
        for (int j = 0; j < h.length; j++) {
            pre[j + 1] = pre[j] + h[j] * h[j];
            pv[j + 1] = pv[j] + (hv[j] ? 1 : 0);
        }
        float[] sc = new float[K];
        int best = -1;
        for (int k = 0; k < K && k + n <= h.length; k++) {
            if (pv[k + n] - pv[k] < n * 0.7) continue;
            double hn = Math.sqrt(pre[k + n] - pre[k]);
            if (hn < 1e-6) continue;
            double d = 0;
            for (int i = 0; i < n; i++) d += c[i] * h[i + k];
            sc[k] = (float) (d / (cn * hn));
            if (best < 0 || sc[k] > sc[best]) best = k;
        }
        if (best < 0) return null;
        float second = 0.05f;
        for (int k = 0; k < K; k++) if (Math.abs(k - best) > 30 && sc[k] > second) second = sc[k];
        double delta = 0;
        if (best > 0 && best < K - 1) {
            double a = sc[best - 1], b = sc[best], cc = sc[best + 1];
            double den = a - 2 * b + cc;
            if (Math.abs(den) > 1e-9) delta = 0.5 * (a - cc) / den;
            if (delta > 0.5) delta = 0.5;
            if (delta < -0.5) delta = -0.5;
        }
        Result r = new Result();
        r.lagMs = (int) Math.round(maxLagMs - 10 * (best + delta));
        r.score = sc[best];
        r.ratio = sc[best] / second;
        return r;
    }

    static void detrend(float[] g, boolean[] v) {
        int n = g.length;
        double[] ps = new double[n + 1];
        int[] pc = new int[n + 1];
        for (int i = 0; i < n; i++) {
            boolean ok = !Float.isNaN(g[i]);
            v[i] = ok;
            ps[i + 1] = ps[i] + (ok ? g[i] : 0);
            pc[i + 1] = pc[i] + (ok ? 1 : 0);
        }
        int w = 25;
        float[] o = new float[n];
        for (int i = 0; i < n; i++) {
            if (!v[i]) continue;
            int a = Math.max(0, i - w), b = Math.min(n, i + w + 1);
            int cnt = Math.max(1, pc[b] - pc[a]);
            o[i] = (float) (g[i] - (ps[b] - ps[a]) / cnt);
        }
        System.arraycopy(o, 0, g, 0, n);
    }
}
