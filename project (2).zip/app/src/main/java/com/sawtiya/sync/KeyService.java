package com.sawtiya.sync;

import android.accessibilityservice.AccessibilityService;
import android.os.SystemClock;
import android.view.KeyEvent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** 1) الزر الأحمر/Audio مرتين = المشغّل العائم. 2) يقرأ اسم قناة الرسيفر من شريط معلومات القناة. */
public class KeyService extends AccessibilityService {
    static final String[] NAME_IDS = {"channel_info_name_tv", "tv_channel_info_program_name", "channel_info_name", "tv_channel_name", "channel_name"};
    static final String[] IDX_IDS = {"channel_info_index_tv", "tv_channel_info_index", "channel_info_index", "channel_index", "tv_channel_number"};
    long lastRed, lastAudio, lastScan;
    final Set<String> diagDone = new HashSet<>();

    @Override public void onInterrupt() {}

    @Override public void onAccessibilityEvent(AccessibilityEvent e) {
        SyncService s = SyncService.I;
        if (s == null || e == null) return;
        CharSequence pkg = e.getPackageName();
        if (pkg != null && pkg.toString().equals(getPackageName())) return;
        long now = SystemClock.uptimeMillis();
        if (now - lastScan < 350) return;
        lastScan = now;
        try {
            scanRoot(s, getRootInActiveWindow());
            List<AccessibilityWindowInfo> ws = getWindows();
            if (ws != null) for (AccessibilityWindowInfo w : ws) scanRoot(s, w.getRoot());
        } catch (Exception ignored) {}
    }

    private void scanRoot(SyncService s, AccessibilityNodeInfo root) {
        if (root == null || root.getPackageName() == null) return;
        String p = root.getPackageName().toString();
        if (p.equals(getPackageName())) return;
        String name = find(root, p, NAME_IDS), idx = find(root, p, IDX_IDS);
        if (name != null && !name.trim().isEmpty()) s.onTvChannel(name.trim(), idx == null ? "" : idx.trim());
        else if (diagDone.add(p)) diag(s, root, p);
    }

    private static String find(AccessibilityNodeInfo root, String pkg, String[] ids) {
        for (String id : ids) {
            List<AccessibilityNodeInfo> l = root.findAccessibilityNodeInfosByViewId(pkg + ":id/" + id);
            if (l == null) continue;
            for (AccessibilityNodeInfo n : l) {
                CharSequence t = n.getText();
                if (t != null && t.length() > 0) return t.toString();
            }
        }
        return null;
    }

    /** تشخيص: يسجل عناصر الشاشة اللي بيها كلمة channel (مرة لكل تطبيق) حتى نعرف أسماء رسيفرك. */
    private void diag(SyncService s, AccessibilityNodeInfo root, String pkg) {
        StringBuilder sb = new StringBuilder();
        walk(root, sb, 0);
        if (sb.length() > 0) s.log("عناصر قناة في " + pkg + ": " + sb);
    }

    private void walk(AccessibilityNodeInfo n, StringBuilder sb, int depth) {
        if (n == null || depth > 25 || sb.length() > 400) return;
        String id = n.getViewIdResourceName();
        if (id != null && id.toLowerCase().contains("channel")) {
            sb.append(id.substring(id.indexOf('/') + 1));
            if (n.getText() != null) sb.append('=').append(n.getText());
            sb.append(' ');
        }
        for (int i = 0; i < n.getChildCount(); i++) walk(n.getChild(i), sb, depth + 1);
    }

    @Override protected boolean onKeyEvent(KeyEvent e) {
        int k = e.getKeyCode();
        boolean red = k == KeyEvent.KEYCODE_PROG_RED;
        boolean audio = k == KeyEvent.KEYCODE_MEDIA_AUDIO_TRACK;
        if (!red && !audio) return false;
        SyncService s = SyncService.I;
        if (s == null) {
            if (e.getAction() == KeyEvent.ACTION_UP) SyncService.start(this);
            return false;
        }
        if (s.overlay.isShown()) return false;
        if (e.getAction() != KeyEvent.ACTION_UP) return false;
        long now = SystemClock.uptimeMillis();
        if (red) {
            if (now - lastRed < 700) { lastRed = 0; s.overlay.show(); return true; }
            lastRed = now;
        } else {
            if (now - lastAudio < 700) { lastAudio = 0; s.overlay.show(); return true; }
            lastAudio = now;
        }
        return false;
    }
}
