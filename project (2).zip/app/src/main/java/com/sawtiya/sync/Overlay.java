package com.sawtiya.sync;

import android.content.Context;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/** المشغّل العائم فوق صورة الرسيفر. رجوع = إخفاء (الصوت يبقى). */
final class Overlay {
    final SyncService s;
    final WindowManager wm;
    LinearLayout root;
    TextView title, status, delay, levels;
    Button syncBtn, muteBtn, playBtn;
    boolean shown;
    final Runnable tick = new Runnable() {
        @Override public void run() { if (shown) { update(); s.main.postDelayed(this, 400); } }
    };

    Overlay(SyncService s) {
        this.s = s;
        wm = (WindowManager) s.getSystemService(Context.WINDOW_SERVICE);
    }

    boolean isShown() { return shown; }

    void toggle() { s.main.post(() -> { if (shown) hide(); else show(); }); }

    void show() {
        s.main.post(() -> {
            if (shown) return;
            if (root == null) build();
            int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                    : WindowManager.LayoutParams.TYPE_PHONE;
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type,
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP | Gravity.END;
            lp.x = 40; lp.y = 40;
            try {
                wm.addView(root, lp);
                shown = true;
                syncBtn.requestFocus();
                s.main.post(tick);
            } catch (Exception e) {
                s.log("تعذر إظهار المشغّل العائم: " + e.getMessage());
            }
        });
    }

    void hide() {
        s.main.post(() -> {
            if (!shown) return;
            try { wm.removeView(root); } catch (Exception ignored) {}
            shown = false;
        });
    }

    private void build() {
        Context c = s;
        root = new LinearLayout(c) {
            @Override public boolean dispatchKeyEvent(KeyEvent e) {
                int k = e.getKeyCode();
                if (k == KeyEvent.KEYCODE_BACK || k == KeyEvent.KEYCODE_PROG_RED) {
                    if (e.getAction() == KeyEvent.ACTION_UP) hide();
                    return true;
                }
                return super.dispatchKeyEvent(e);
            }
        };
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setPadding(28, 22, 28, 22);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.argb(235, 14, 22, 44));
        bg.setCornerRadius(28);
        bg.setStroke(2, Color.rgb(60, 110, 170));
        root.setBackground(bg);

        title = tv(19, Color.WHITE);
        status = tv(18, Color.rgb(80, 230, 220));
        delay = tv(14, Color.rgb(200, 212, 235));
        levels = tv(12, Color.rgb(160, 175, 205));
        root.addView(title); root.addView(status); root.addView(delay); root.addView(levels);

        syncBtn = b("زامن الآن", v -> s.syncNow());
        muteBtn = b("كتم القناة", v -> { s.setChannelMuted(!s.channelMuted); s.synced = s.channelMuted && s.synced; });
        root.addView(row(syncBtn, muteBtn));
        playBtn = b("إيقاف مؤقت", v -> s.togglePlay());
        root.addView(row(
                b("−0.1", v -> s.adjustDelay(-100)),
                b("+0.1", v -> s.adjustDelay(100)),
                b("إخفاء", v -> hide())));
        root.setMinimumWidth(560);
    }

    private void update() {
        title.setText(s.header());
        status.setText(s.status);
        delay.setText(s.delayText());
        levels.setText(s.syncing ? s.levelsText() : "رجوع أو الأحمر = إخفاء");
        syncBtn.setText(s.syncing ? "إلغاء المزامنة" : "زامن الآن");
        muteBtn.setText(s.channelMuted ? "سماع القناة" : "كتم القناة");
    }

    private TextView tv(int sp, int color) {
        TextView t = new TextView(s);
        t.setTextSize(sp); t.setTextColor(color); t.setPadding(6, 4, 6, 4);
        t.setTypeface(Fonts.get(s));
        return t;
    }

    private Button b(String text, View.OnClickListener l) {
        Button b = new Button(s);
        b.setText(text); b.setTextSize(16); b.setAllCaps(false);
        b.setTypeface(Fonts.get(s));
        b.setFocusable(true); b.setOnClickListener(l);
        return b;
    }

    private LinearLayout row(View... vs) {
        LinearLayout r = new LinearLayout(s);
        r.setOrientation(LinearLayout.HORIZONTAL);
        for (View v : vs) r.addView(v, new LinearLayout.LayoutParams(0, -2, 1f));
        return r;
    }
}
