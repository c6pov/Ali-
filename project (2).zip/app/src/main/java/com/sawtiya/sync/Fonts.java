package com.sawtiya.sync;

import android.content.Context;
import android.graphics.Typeface;

final class Fonts {
    private static Typeface tf;
    static Typeface get(Context c) {
        if (tf == null) {
            try { tf = Typeface.createFromAsset(c.getAssets(), "thmanyah.otf"); }
            catch (Exception e) { tf = Typeface.DEFAULT_BOLD; }
        }
        return tf;
    }
}
