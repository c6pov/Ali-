package com.sawtiya.sync;

import android.os.SystemClock;
import android.system.Os;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.util.concurrent.TimeUnit;

/** يلتقط صوت القناة من Loopback كرت الصوت عبر tinycap (يحتاج صلاحية نظام). */
final class Capture {
    interface Log { void log(String s); }

    final Track track;
    final Log log;
    final float[] levels = new float[8];
    volatile int mask = 0xFF;
    volatile boolean running;
    private Process proc;
    private File fifo;
    private Thread th;

    Capture(Track track, Log log) { this.track = track; this.log = log; }

    synchronized boolean start(File cacheDir) {
        stop();
        for (int c = 0; c < levels.length; c++) levels[c] = 0;
        log.log("فحص التقاط صوت القناة: tinycap -l");
        dumpCaptureDevices();
        try { Runtime.getRuntime().exec(new String[]{"pkill", "-f", "sawtiya-cap-"}).waitFor(); } catch (Exception ignored) {}
        File[] old = cacheDir.listFiles();
        if (old != null) for (File f : old) if (f.getName().startsWith("sawtiya-cap-")) f.delete();
        fifo = new File(cacheDir, "sawtiya-cap-" + System.nanoTime() + ".pipe");
        try {
            Os.mkfifo(fifo.getAbsolutePath(), 0600);
            String[] command = {"/system/bin/tinycap", fifo.getAbsolutePath(),
                    "-D", "0", "-d", "7", "-c", "8", "-r", "48000", "-b", "16"};
            log.log("أمر الالتقاط الحالي: card=0 device=7 channels=8 rate=48000 bits=16");
            proc = new ProcessBuilder(command).redirectErrorStream(true).start();
        } catch (Exception e) {
            log.log("تعذر تشغيل tinycap: " + e.getMessage());
            return false;
        }
        running = true;
        final Process p = proc;
        new Thread(() -> {
            try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
                String s; int k = 0;
                while ((s = r.readLine()) != null) if (k++ < 4) log.log("tinycap: " + s);
            } catch (Exception ignored) {}
        }, "cap-out").start();
        final File f = fifo;
        th = new Thread(() -> loop(f), "cap");
        th.start();
        return true;
    }

    /** يقرأ قائمة أجهزة الالتقاط من tinyalsa دون تغيير أي إعداد في الرسيفر. */
    private void dumpCaptureDevices() {
        Process p = null;
        try {
            p = new ProcessBuilder("/system/bin/tinycap", "-l").redirectErrorStream(true).start();
            boolean done = p.waitFor(2500, TimeUnit.MILLISECONDS);
            if (!done) {
                p.destroy();
                log.log("فحص tinycap -l: انتهت مهلة 2.5 ثانية؛ لم يرجع قائمة الأجهزة");
                return;
            }
            StringBuilder output = new StringBuilder();
            try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
                String line; int count = 0;
                while ((line = r.readLine()) != null && count++ < 30) {
                    if (output.length() < 3500) output.append(line).append(" | ");
                }
            }
            log.log("قائمة أجهزة tinycap (exit=" + p.exitValue() + "): " +
                    (output.length() == 0 ? "لا يوجد خرج؛ قد لا يدعم هذا الإصدار -l" : output.toString()));
        } catch (Exception e) {
            log.log("تعذر فحص قائمة أجهزة tinycap: " + e.getClass().getSimpleName() + ": " + e.getMessage());
            if (p != null) p.destroy();
        }
    }

    private void loop(File f) {
        Onset onset = new Onset(48000, track);
        try (FileInputStream in = new FileInputStream(f)) {
            byte[] b = new byte[16 * 960];
            float[] mono = new float[960];
            float[] pk = new float[8];
            int have = 0;
            long totalBytes = 0;
            long lastReport = SystemClock.elapsedRealtime();
            boolean first = true;
            boolean sawNonZero = false;
            while (running) {
                int r = in.read(b, have, b.length - have);
                if (r < 0) break;
                if (r == 0) continue;
                have += r;
                totalBytes += r;
                if (first) {
                    if (have < 44) continue;
                    first = false;
                    if (b[0] == 'R' && b[1] == 'I' && b[2] == 'F' && b[3] == 'F') {
                        System.arraycopy(b, 44, b, 0, have - 44);
                        have -= 44;
                    }
                }
                int frames = have / 16;
                if (frames == 0) continue;
                int m = mask;
                int cnt = Math.max(1, Integer.bitCount(m));
                for (int fr = 0; fr < frames; fr++) {
                    float s = 0;
                    for (int c = 0; c < 8; c++) {
                        int o = fr * 16 + c * 2;
                        short v = (short) ((b[o] & 0xff) | (b[o + 1] << 8));
                        float x = v / 32768f;
                        float a = Math.abs(x);
                        if (a > pk[c]) pk[c] = a;
                        if (a > 0.0005f) sawNonZero = true;
                        if (((m >> c) & 1) != 0) s += x;
                    }
                    mono[fr] = s / cnt;
                }
                onset.push(mono, frames, SystemClock.elapsedRealtime() - 20);
                for (int c = 0; c < 8; c++) { levels[c] = levels[c] * 0.8f + pk[c] * 0.2f; pk[c] = 0; }
                long reportNow = SystemClock.elapsedRealtime();
                if (reportNow - lastReport >= 5000) {
                    float max = 0; for (float level : levels) max = Math.max(max, level);
                    log.log("تشخيص الالتقاط: bytes=" + totalBytes + " maxLevel=" + max +
                            " nonZero=" + sawNonZero + " (8ch/48kHz/16bit)");
                    lastReport = reportNow;
                }
                int used = frames * 16;
                System.arraycopy(b, used, b, 0, have - used);
                have -= used;
            }
        } catch (Exception e) {
            if (running) log.log("توقف التقاط صوت القناة: " + e.getClass().getSimpleName() + ": " + e.getMessage());
        }
        if (running) log.log("انتهى تدفق الالتقاط؛ تحقق من tinycap ومصدر الصوت");
        running = false;
    }

    synchronized void stop() {
        running = false;
        if (proc != null) { proc.destroy(); proc = null; }
        final File f = fifo;
        if (f != null) {
            // يفك أي انتظار على فتح الأنبوب
            new Thread(() -> { try { new FileOutputStream(f).close(); } catch (Exception ignored) {} f.delete(); }).start();
            fifo = null;
        }
        th = null;
        for (int c = 0; c < 8; c++) levels[c] = 0;
    }
}
