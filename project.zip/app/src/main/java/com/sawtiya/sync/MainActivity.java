package com.sawtiya.sync;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** المرحلة 1: تجربة التحكم بالرسيفر (تأخير الصورة + كتم صوت القناة) وفحص الصلاحيات. */
public class MainActivity extends Activity {
    static final int PORT = 51021;
    static final String RX_ACTION = "com.tms.message.in.action";

    final Handler ui = new Handler(Looper.getMainLooper());
    int delayMs = 0;
    TextView delayText, logText;
    BroadcastReceiver rx;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(48, 32, 48, 32);
        root.setBackgroundColor(Color.rgb(12, 20, 40));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        TextView title = text("مزامنة الصوتية — المرحلة 1 (تجربة الرسيفر)", 26);
        root.addView(title);
        delayText = text("تأخير الصورة: 0.0 ث", 30);
        delayText.setTextColor(Color.rgb(80, 230, 220));
        root.addView(delayText);

        root.addView(row(
            btn("−1 ث", v -> setDelay(delayMs - 1000)),
            btn("−0.1 ث", v -> setDelay(delayMs - 100)),
            btn("+0.1 ث", v -> setDelay(delayMs + 100)),
            btn("+1 ث", v -> setDelay(delayMs + 1000))));
        root.addView(row(
            btn("صفر", v -> setDelay(0)),
            btn("2 ث", v -> setDelay(2000)),
            btn("5 ث", v -> setDelay(5000)),
            btn("10 ث", v -> setDelay(10000))));
        root.addView(row(
            btn("كتم صوت القناة (0)", v -> send("0117", "0")),
            btn("إرجاع صوت القناة (1)", v -> send("0117", "1")),
            btn("فحص الصلاحيات", v -> checkSystem())));

        logText = text("", 18);
        logText.setTextColor(Color.rgb(200, 210, 230));
        ScrollView sv = new ScrollView(this);
        sv.addView(logText);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(root);

        rx = new BroadcastReceiver() {
            @Override public void onReceive(Context c, Intent i) {
                StringBuilder sb = new StringBuilder("الرسيفر يقول:");
                Bundle e = i.getExtras();
                if (e != null) for (String k : e.keySet()) sb.append(' ').append(k).append('=').append(e.get(k));
                log(sb.toString());
            }
        };
        IntentFilter f = new IntentFilter(RX_ACTION);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(rx, f, Context.RECEIVER_EXPORTED);
        else registerReceiver(rx, f);

        checkSystem();
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        try { unregisterReceiver(rx); } catch (Exception ignored) {}
    }

    void setDelay(int ms) {
        delayMs = Math.max(0, Math.min(60000, ms));
        delayText.setText(String.format(Locale.US, "تأخير الصورة: %.1f ث", delayMs / 1000f));
        send("0118", String.valueOf(delayMs));
    }

    /** يرسل أمر للرسيفر على 127.0.0.1:51021 ويطبع الرد إن وُجد. */
    void send(String code, String value) {
        final String msg = "Play\n" + code + "\n" + value;
        new Thread(() -> {
            try (DatagramSocket s = new DatagramSocket()) {
                byte[] out = msg.getBytes(StandardCharsets.US_ASCII);
                s.send(new DatagramPacket(out, out.length, InetAddress.getByName("127.0.0.1"), PORT));
                log("أُرسل: " + code + " = " + value);
                s.setSoTimeout(800);
                byte[] buf = new byte[512];
                DatagramPacket in = new DatagramPacket(buf, buf.length);
                try {
                    s.receive(in);
                    log("رد المحرك: " + new String(buf, 0, in.getLength(), StandardCharsets.US_ASCII).replace('\n', ' '));
                } catch (java.net.SocketTimeoutException t) {
                    log("(بدون رد — طبيعي بأمر التأخير)");
                }
            } catch (Exception ex) {
                log("فشل الإرسال: " + ex);
            }
        }).start();
    }

    void checkSystem() {
        int uid = Process.myUid();
        log("UID = " + uid + (uid == 1000 ? "  ✓ صلاحية نظام (التوقيع صحيح)" : "  ✗ مو تطبيق نظام"));
        log("tinycap: " + (new File("/system/bin/tinycap").exists() ? "موجود ✓" : "غير موجود ✗"));
        try (BufferedReader r = new BufferedReader(new FileReader("/proc/asound/card0/pcm7c/info"))) {
            String l; boolean loop = false;
            while ((l = r.readLine()) != null) if (l.toUpperCase(Locale.ROOT).contains("LOOPBACK")) loop = true;
            log("Loopback صوت القناة: " + (loop ? "موجود ✓" : "مو واضح ✗"));
        } catch (Exception e) {
            log("Loopback صوت القناة: ما نكدر نقرأه (" + e.getMessage() + ")");
        }
    }

    void log(String s) {
        String t = new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date());
        ui.post(() -> logText.setText(t + "  " + s + "\n" + logText.getText()));
    }

    TextView text(String s, int sp) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(sp); t.setTextColor(Color.WHITE);
        t.setPadding(8, 12, 8, 12); t.setGravity(Gravity.START);
        return t;
    }

    Button btn(String s, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(s); b.setTextSize(20); b.setAllCaps(false);
        b.setFocusable(true); b.setOnClickListener(l);
        return b;
    }

    LinearLayout row(View... vs) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        for (View v : vs) r.addView(v, new LinearLayout.LayoutParams(0, -2, 1f));
        return r;
    }
}
